# -*- coding: utf-8 -*-
"""
Created on Tue Jun 23 13:12:51 2020

@author: swetha.sridhar
"""
import re
import joblib
import warnings
warnings.filterwarnings("ignore")
from flask import Flask, request 
from flasgger import Swagger


loaded_model_tfidf = joblib.load('./tfidf_vectorizer_new.pickle')
ml_model = joblib.load('./multinomial_nb_model_new.pickle')


app = Flask(__name__)
swagger = Swagger(app)

@app.route('/predict')
def predict_genre():
    """Example endpoint returning a prediction of genres
    ---
    parameters:
      - name: text_ip
        in: query
        type: string
        required: true
    responses:
      500:
        description: Error! Check your code
      200:
        description: It works!
        schema:
          id: awesome
          properties:
            text_ip:
              type: string
              description: The genre name
              default: drama
            features:
              type: array
              description: The genre list
              items:
                type: string
              default: ["action", "drama", "comedy"]
    """
    text_ip = request.args.get("text_ip")
    PlotClean= clean_text(str(text_ip))
    x_test_tfidf  = loaded_model_tfidf.transform([PlotClean])
    prediction = ml_model.predict(x_test_tfidf)
    return str(list(prediction))



    
def clean_text(text):
    text = text.lower()
    text = re.sub(r"what's", "what is ", text)
    text = re.sub(r"\'s", " ", text)
    text = re.sub(r"\'ve", " have ", text)
    text = re.sub(r"can't", "can not ", text)
    text = re.sub(r"n't", " not ", text)
    text = re.sub(r"i'm", "i am ", text)
    text = re.sub(r"\'re", " are ", text)
    text = re.sub(r"\'d", " would ", text)
    text = re.sub(r"\'ll", " will ", text)
    text = re.sub(r"\'scuse", " excuse ", text)
    text = re.sub('\W', ' ', text)
    text = re.sub('\s+', ' ', text)
    text = text.strip(' ')
    return text


if __name__ == '__main__':
    app.run(port = 5000)

#text_ip = "Greed and class discrimination threaten the newly formed symbiotic relationship between the wealthy Park family and the destitute Kim clan."
#PlotClean= clean_text(text_ip)
#print(PlotClean)

#Load tfidf vectorizer 
#loaded_model_tfidf = pickle.load(open('tfidf_vectorizer.sav', 'rb'))
#loaded_model_tfidf = joblib.load('tfidf_vectorizer_new.pickle')
#x_test_tfidf  = loaded_model_tfidf.transform([PlotClean])
#print(x_test_tfidf)



#ml model 
#ml_model = joblib.load('multinomial_nb_model_new.pickle')
#prediction = ml_model.predict(x_test_tfidf)
#print(prediction)


